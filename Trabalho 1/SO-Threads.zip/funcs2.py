from unicodedata import normalize
from os import walk

def most_frequent(List): 
    return max(set(List), key = List.count) 

# -Faça um programa que, dado um diretório com arquivos de texto no formato .txt, calcule as seguintes estatísticas para cada arquivo. 
# -Número de palavras,
# -número de vogais,
# -número de consoantes, 
# -palavra que apareceu mais vezes no arquivo, 

# -vogal mais frequente, 
# -consoantes mais frequente. 
# -Além disso, para cada arquivo do diretório, o programa deverá gerar um novo arquivo, contendo o conteúdo do arquivo original escrito em letras maiúsculas.
def estatistica(arquivo):
    arq = open(arquivo, "r").read()
    arq = arq.lower() # coloca tudo em minusculo pra contagem de palavras não ser Case-sensitive
    arq = arq.replace("\n", " ") # remove terminos de linha
    arq = arq.replace(",", " ") # remove virgulas
    arq = arq.replace(".", " ") # remove pontos
    arq = arq.replace("  ", " ") #remove espaços duplicados pelas anteriores
    # print(arq)
    arq = normalize('NFKD', arq).encode('ASCII', 'ignore').decode('ASCII') #remove acentuação
    # print(arq)
    arq = arq.split(" ")

    palavras = []
    vogais = []
    consoantes = []

    arq.remove("")
    for palavra in arq:
        if palavra not in palavras :
            palavras.append(palavra)
        for letra in palavra:
            if letra == "a" or letra == "e" or letra == "i" or letra == "o" or letra == "u":
                vogais.append(letra)
            else:
                consoantes.append(letra)


    # print(arq)
    # print(palavras)
    print("número de palavras no arquivo: ", len(arq))
    print("número de palavras, sem repetir, no arquivo: ", len(palavras))

    print("número de vogais: ", len(vogais))
    print("número de consoantes: ", len(consoantes))
    print("palavra que mais apareceu no arquivo: ", most_frequent(arq))
    print("vogal que mais apareceu no arquivo: ", most_frequent(vogais))
    print("consoante que mais apareceu no arquivo: ", most_frequent(consoantes))

def ex3():
    files = []
    path = ''

    for (dirpath, dirnames, filenames) in walk(path):
        print(dirpath, dirnames, filenames)
        files.extend(filenames)
    

    print(files)