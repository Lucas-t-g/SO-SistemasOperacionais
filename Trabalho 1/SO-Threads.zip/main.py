from funcs import *
from funcs2 import *
# ex1()
# ex2()
# estatistica("text.txt")
ex3()
